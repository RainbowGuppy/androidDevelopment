//--------------START USER CODE------------------------------------
//--------------END USER CODE------------------------------------

package edu.hstumps.littlepiggame;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

//--------------START USER CODE------------------------------------

//--------------END USER CODE------------------------------------

public class MainActivity extends AppCompatActivity {

    //--------------START USER CODE------------------------------------
    private EditText player1Name; //declare the player 1s name
    private EditText player2Name; //depclare the player 2s name
    private TextView player1Score; //declare the player 1s score
    private TextView player2Score; //declare the player 2s score
    private TextView currentPlayer; //declare the current player
    private TextView currentPlayerScore; //declare the current players score
    private Button rollDieButton;
    private Button endTurnButton;
    private Button newGameButton;
    private ImageView diceImage;

    private PigGame game = new PigGame(); //calling the seperate java file
    //this defines the sharedPreferences object
    private SharedPreferences savedValues;
    //--------------END USER CODE------------------------------------

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //--------------START USER CODE------------------------------------
        //reference to the widgets
        player1Name = (EditText)findViewById(R.id.player1EditText);
        player2Name = (EditText)findViewById(R.id.player2EditText);
        player1Score = (TextView)findViewById(R.id.player1Score);
        player2Score = (TextView)findViewById(R.id.player2Score);
        currentPlayer = (TextView)findViewById(R.id.playerNameLabel);
        currentPlayerScore = (TextView)findViewById(R.id.pointsTextView);
        rollDieButton = (Button)findViewById(R.id.rollDieButton);
        endTurnButton = (Button)findViewById(R.id.endTurnButton);
        newGameButton = (Button)findViewById(R.id.endGameButton);
        diceImage = (ImageView)findViewById(R.id.imageView);

        //--------------END USER CODE------------------------------------


        rollDieButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {

                Log.d("Button", "onClick: you clicked the roll die button!");
                rollDie();
                //do a thing
            }
        });

        endTurnButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Log.d("Button", "onClick: you clicked the end turn button!");
                //do a thing
            }
        });

        endTurnButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Log.d("Button", "onClick: you clicked the end turn button!");
                //do a thing
            }
        });

        newGameButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Log.d("Button", "onClick: you clicked the new game button!");
                //do a thing
            }
        });

        //get sharedpreferences here
        //savedValues = getSharedPreferences("savedValues", MODE_PRIVATE);
    }

    //--------------START USER CODE-----------------------------------
    @Override
    public void onPause(){
        //save the variables that you want
        Editor editor = savedValues.edit();
        //editor.putString("player1Name", player1Name);//save the player1s name
        //editor.putString("player2EditText", player2Name);//save the player2s name
        //editor.putString("", whichPlayerTurn);//save whos turn it is

        //editor.putFloat("", player1Score);//save the player1s total score
        //editor.putFloat("", player2Score);//save the player2s total score
        //editor.putFloat("", currentTurnScore);//save the current points
        editor.commit();
        super.onPause();
    }

    @Override
    public void onResume(){
        super.onResume();
        //get the instance variables
        //player1Name = savedValues.getString("player1Name","");
    }

    public void rollDie()
    {
        int id = 0;//id for the image

        Random r = new Random();
        int diceNumber = r.nextInt(7 - 1) + 1;

        switch (diceNumber){
            case 1:
                //display dice 1
                id = R.drawable.die1;
                break;
            case 2:
                //display dice 2
                id = R.drawable.die2;
                break;
            case 3:
                //display dice 3
                id = R.drawable.die3;
                break;
            case 4:
                //display dice 4
                id = R.drawable.die4;
                break;
            case 5:
                //display dice 5
                id = R.drawable.die5;
                break;
            case 6:
                //display dice 6
                id = R.drawable.die6;
                break;

            default:
                //there was an error
                Log.d("error", "There was an error");
        }
        diceImage.setImageResource(id);

    }
    //--------------END USER CODE------------------------------------

    public void perTurn()
    {
        //change the current player
        //check valid roll, if not valid
        //{
            //disable roll button
            //set current score to 0
        //}
    }


}
